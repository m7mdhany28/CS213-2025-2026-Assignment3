var class_infinity___board =
[
    [ "Infinity_Board", "class_infinity___board.html#a70c26a8f29d4d3ba36e948e7b2400a5d", null ],
    [ "display_board", "class_infinity___board.html#a2fa52933db215d59aeecf3464a0147d4", null ],
    [ "game_is_over", "class_infinity___board.html#a269b17b6ede5bd97bcf60a28e04a83d3", null ],
    [ "get_removal_countdown", "class_infinity___board.html#a995d8d5097b13daad3137c57beb9b397", null ],
    [ "get_total_moves", "class_infinity___board.html#abeb805ad21cad091f568c83dcade04e6", null ],
    [ "is_draw", "class_infinity___board.html#ab0ea3f487553c34a33af3e99550b264e", null ],
    [ "is_lose", "class_infinity___board.html#a8fd0b622495f2ccf2eed22ea0f8b1205", null ],
    [ "is_win", "class_infinity___board.html#a0d93549c5b8a55ce0e02f1b2514d6649", null ],
    [ "remove_oldest_mark", "class_infinity___board.html#a6f51a8fa6b6bb98f639a87a2aa063b05", null ],
    [ "update_board", "class_infinity___board.html#a73168748decfd8a3bfa9044409d728aa", null ],
    [ "move_timestamps", "class_infinity___board.html#ae296f03e80840e9605498cf078a4d21c", null ],
    [ "moves_since_last_removal", "class_infinity___board.html#a356e4a4f238650ebf980009f7979adfd", null ],
    [ "total_moves", "class_infinity___board.html#a5ca3b3f82d14d26b114b9f1217a942f7", null ]
];