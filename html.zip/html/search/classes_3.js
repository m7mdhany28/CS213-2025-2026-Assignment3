var searchData=
[
  ['gamemanager_0',['GameManager',['../class_game_manager.html',1,'']]]
];
