var searchData=
[
  ['winner_0',['winner',['../class_pyramid_tic_tac_toe.html#a9a145a84d5d887eb75bc7520770b2622',1,'PyramidTicTacToe']]],
  ['winning_5flines_1',['winning_lines',['../class_pyramid_tic_tac_toe.html#ac4a8299c66eb8b6a7f7dadb8e712e623',1,'PyramidTicTacToe']]]
];
