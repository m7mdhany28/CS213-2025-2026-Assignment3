var searchData=
[
  ['board_0',['Board',['../class_board.html#ae5dfded241ee3644196e2f6074d1d0b1',1,'Board']]]
];
