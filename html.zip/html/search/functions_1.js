var searchData=
[
  ['calculate_5fplayers_5fscore_0',['calculate_players_score',['../class_s_u_s___board.html#ad9b301a7f2bcb678bbec370905983809',1,'SUS_Board']]],
  ['check_5ffor_5fwords_1',['check_for_words',['../class_word_tic_tac_toe___board.html#a2c9f11199899ea984c84dbf17423e415',1,'WordTicTacToe_Board']]],
  ['check_5fline_5flength_2',['check_line_length',['../class_diamond___board.html#a0a2b2ac2bafa20ab37e600f241511d71',1,'Diamond_Board']]],
  ['check_5fthree_5fin_5frow_3',['check_three_in_row',['../class_simple___u_i.html#a0608c2a2725e8627640dbb11825492c1',1,'Simple_UI']]],
  ['check_5fwin_4',['check_win',['../class_four_by_four___moving___board.html#a45ee25efed833522c8bf323ecc98800a',1,'FourByFour_Moving_Board']]],
  ['checkwin_5',['checkWin',['../class_pyramid_tic_tac_toe.html#a5d767ac2c8403a37b38f5bdcc64ba669',1,'PyramidTicTacToe::checkWin(const vector&lt; vector&lt; char &gt; &gt; &amp;testBoard) const'],['../class_pyramid_tic_tac_toe.html#a4213d3dbfbafc72d40b8ffbf4ce9f258',1,'PyramidTicTacToe::checkWin() const']]],
  ['chooseplayerpersonality_6',['choosePlayerPersonality',['../_play_game_functions_8h.html#af79f90289f726743b7076a84a4122142',1,'choosePlayerPersonality(const std::string &amp;playerLabel):&#160;PlayGameFunctions.h'],['../_play_game_functions_8cpp.html#a944c1e2fe87c96833f95fb027c72e3bd',1,'choosePlayerPersonality(const string &amp;playerLabel):&#160;PlayGameFunctions.cpp']]],
  ['count_5fplayer_5fsequences_7',['count_player_sequences',['../class_five_by_five___board.html#af22b339b35d72f46b14ab3a037883ec7',1,'FiveByFive_Board']]],
  ['count_5fsequences_8',['count_sequences',['../class_simple___u_i.html#aab8130b068ef76de3f527f480565de41',1,'Simple_UI']]],
  ['create_5fplayer_9',['create_player',['../class_u_i.html#a94561e0bb4bbcbe5ff71ca6d751922df',1,'UI::create_player()'],['../class_diamond___u_i.html#a9c4e43d9cf1a603c3e487bbfabd13a83',1,'Diamond_UI::create_player()'],['../class_four_in_row___u_i.html#aa09a5ccc815f80282545e1875805d7e1',1,'FourInRow_UI::create_player()'],['../class_memory_game___u_i.html#add442ba5ee4d6bb856fc1e475c1004fc',1,'MemoryGame_UI::create_player()'],['../class_numerical___u_i.html#adac3d3b9c67ce9aad8e6dba34db8a8b2',1,'Numerical_UI::create_player()'],['../class_simple___u_i.html#a5623af435a66b0d1b3876c79e88fff47',1,'Simple_UI::create_player()'],['../class_s_u_s___u_i.html#ae510c6c91efc4a17d7dadb4282e00e84',1,'SUS_UI::create_player()'],['../class_x_o___u_i.html#abd2ec8bc2c0ad1e60499c84e45ad6776',1,'XO_UI::create_player()']]]
];
