var searchData=
[
  ['cell_5fwidth_0',['cell_width',['../class_u_i.html#a6c79c489ae9aa3a7860fb58e5a14ddfe',1,'UI']]],
  ['columns_1',['columns',['../class_board.html#afaf8842d9d52ac724e8c2f5642ecafc7',1,'Board']]],
  ['currentplayer_2',['currentPlayer',['../class_pyramid_tic_tac_toe.html#a44d9b9e7df666f41afe36ca08b9cd890',1,'PyramidTicTacToe']]]
];
