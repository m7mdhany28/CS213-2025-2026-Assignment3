var searchData=
[
  ['human_0',['HUMAN',['../_board_game___classes_8h.html#abe590f3c9109f404f003d5d7e4f0fccfaa36c6719f4d3207d858cf956ef1e93b6',1,'BoardGame_Classes.h']]]
];
