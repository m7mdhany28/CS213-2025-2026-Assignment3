var searchData=
[
  ['numericalgame_0',['NUMERICALGAME',['../class_main_screen.html#a5e0cc247f5b321d4dfb8367e75e53e00a804a3370c931aaf1c0e6410ad5f63016',1,'MainScreen']]]
];
