var _infinity___board_8h =
[
    [ "Infinity_Board", "class_infinity___board.html", "class_infinity___board" ],
    [ "INFINITY_BOARD_H", "_infinity___board_8h.html#a9e794bf7e939d57920541f28e107e930", null ]
];