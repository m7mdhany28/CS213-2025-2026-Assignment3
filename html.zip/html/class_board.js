var class_board =
[
    [ "Board", "class_board.html#ae5dfded241ee3644196e2f6074d1d0b1", null ],
    [ "~Board", "class_board.html#a138a6378af669dd1ce55dc11217aea48", null ],
    [ "game_is_over", "class_board.html#ae0e4575ec3cc4b6eb9f367ffb2beed13", null ],
    [ "get_board_matrix", "class_board.html#a117f2e61fdb7deccca333bbbc9c62d3a", null ],
    [ "get_cell", "class_board.html#a93558c58e60ca4291c6044828afd260b", null ],
    [ "get_columns", "class_board.html#ac665e1ed1f49125fab248e2c9ddfd608", null ],
    [ "get_n_moves", "class_board.html#a512d0bd8c282985c410d677c82eb3b78", null ],
    [ "get_rows", "class_board.html#a93b130eff67bd4476fab27be8341cb78", null ],
    [ "is_draw", "class_board.html#a8dbe2a243881986f3e53b45799d377fc", null ],
    [ "is_lose", "class_board.html#a207d5f6feb77f81c51d1462f0245890d", null ],
    [ "is_win", "class_board.html#ab316fe3e79677b4617fc3d90d6c48f33", null ],
    [ "update_board", "class_board.html#a93d9dec601dda58b7e206ccb47633e57", null ],
    [ "board", "class_board.html#af00c1fc363eb640ca276b8a572040040", null ],
    [ "columns", "class_board.html#afaf8842d9d52ac724e8c2f5642ecafc7", null ],
    [ "n_moves", "class_board.html#a5952baefabced65fecec333de638408d", null ],
    [ "rows", "class_board.html#a948d978e3b5fc460559b588f5dee9572", null ]
];