var searchData=
[
  ['numerical_5fboard_0',['Numerical_Board',['../class_numerical___board.html',1,'']]],
  ['numerical_5fui_1',['Numerical_UI',['../class_numerical___u_i.html',1,'']]]
];
