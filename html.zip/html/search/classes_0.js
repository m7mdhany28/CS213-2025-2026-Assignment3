var searchData=
[
  ['board_0',['Board',['../class_board.html',1,'']]],
  ['board_3c_20char_20_3e_1',['Board&lt; char &gt;',['../class_board.html',1,'']]],
  ['board_3c_20int_20_3e_2',['Board&lt; int &gt;',['../class_board.html',1,'']]]
];
