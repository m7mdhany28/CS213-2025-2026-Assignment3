var searchData=
[
  ['valid_5fmove_0',['valid_move',['../class_four_in_row___board.html#a579f35f6c05cbeabf58977079fe4b227',1,'FourInRow_Board::valid_move()'],['../class_s_u_s___board.html#a7fc185f07055fd7e3252f24d46612919',1,'SUS_Board::valid_move()']]]
];
