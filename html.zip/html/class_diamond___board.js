var class_diamond___board =
[
    [ "Diamond_Board", "class_diamond___board.html#a46b141be4a62a22373d34ef04c9c536a", null ],
    [ "check_line_length", "class_diamond___board.html#a0a2b2ac2bafa20ab37e600f241511d71", null ],
    [ "game_is_over", "class_diamond___board.html#ab9a80d3f5348d69311542f419b15be91", null ],
    [ "is_draw", "class_diamond___board.html#acd5e376d6a158790d64b6af810e19208", null ],
    [ "is_lose", "class_diamond___board.html#a963adffd95243c1f94da56df13a1e302", null ],
    [ "is_valid_position", "class_diamond___board.html#a2979a6b9ca66f69e7d53880a25e059c1", null ],
    [ "is_win", "class_diamond___board.html#a572e15094b77d71aa6d9cd10678590df", null ],
    [ "update_board", "class_diamond___board.html#a83aa6596af67e9358f87e2e8b46ff966", null ],
    [ "blank_symbol", "class_diamond___board.html#a0dd31d2e697f92110c1b8f7e77023fd8", null ]
];