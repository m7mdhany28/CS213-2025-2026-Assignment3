var searchData=
[
  ['invalid_5fmove_5fcounts_0',['invalid_move_counts',['../class_simple___u_i.html#a603b3be2161e975c47ddaa1e2b8241de',1,'Simple_UI']]]
];
