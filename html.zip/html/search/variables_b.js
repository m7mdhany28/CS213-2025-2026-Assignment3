var searchData=
[
  ['player_5fownership_0',['player_ownership',['../class_word_tic_tac_toe___board.html#ac7a9cc4e374415414260c1442e6a8ce0',1,'WordTicTacToe_Board']]],
  ['players_1',['players',['../class_game_manager.html#abc7b7dc6bd0e89a29886ace8a7db60bd',1,'GameManager']]],
  ['position_5fweights_2',['position_weights',['../class_pyramid_tic_tac_toe.html#a673b784b3359006777a950ed377d69eb',1,'PyramidTicTacToe']]],
  ['pyramid_5fgame_3',['pyramid_game',['../class_simple___u_i.html#a0811e2412def22c613a6a96b66fc6c2d',1,'Simple_UI']]]
];
