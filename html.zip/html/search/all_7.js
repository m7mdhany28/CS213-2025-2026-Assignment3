var searchData=
[
  ['has_5fthree_5fin_5frow_0',['has_three_in_row',['../class_misere___board.html#a0b2a63ab492118c7881b0479d937f654',1,'Misere_Board']]],
  ['has_5fvalid_5fmoves_1',['has_valid_moves',['../class_four_by_four___moving___board.html#a8f513fb1f8babbf967a120590d1a8cef',1,'FourByFour_Moving_Board']]],
  ['human_2',['HUMAN',['../_board_game___classes_8h.html#abe590f3c9109f404f003d5d7e4f0fccfaa36c6719f4d3207d858cf956ef1e93b6',1,'BoardGame_Classes.h']]]
];
