var class_five_by_five___board =
[
    [ "FiveByFive_Board", "class_five_by_five___board.html#aa0fa14ef0d659af87ccb32abd1399763", null ],
    [ "count_player_sequences", "class_five_by_five___board.html#af22b339b35d72f46b14ab3a037883ec7", null ],
    [ "display_board", "class_five_by_five___board.html#a60d6a6a00175ae92a9ba4c618ab18c9d", null ],
    [ "game_is_over", "class_five_by_five___board.html#ac0889699d6403fb18e84e3c91f6c347e", null ],
    [ "get_board_matrix", "class_five_by_five___board.html#a536a090835d453c76e9fdd3dc1973488", null ],
    [ "is_draw", "class_five_by_five___board.html#a0f1747ab7efedce23295d04327e8bca3", null ],
    [ "is_lose", "class_five_by_five___board.html#ae19cc701ef1cd16a25029b86b1e1716e", null ],
    [ "is_win", "class_five_by_five___board.html#a32a6629dadbeda65748d541ab1ddb335", null ],
    [ "update_board", "class_five_by_five___board.html#aad484568d9828dd29ac172fe9b708a5c", null ],
    [ "would_create_sequence", "class_five_by_five___board.html#a8d10b124aed774dc9923ed2c70149832", null ]
];