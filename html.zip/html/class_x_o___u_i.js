var class_x_o___u_i =
[
    [ "XO_UI", "class_x_o___u_i.html#a3777235b2b66dc912258a4ee20501ebb", null ],
    [ "~XO_UI", "class_x_o___u_i.html#a6c58a77a2fa80f73e7076ca4a94fcc8a", null ],
    [ "create_player", "class_x_o___u_i.html#abd2ec8bc2c0ad1e60499c84e45ad6776", null ],
    [ "get_AI_move", "class_x_o___u_i.html#a836fe5c1ac61fc4d35861813bb48ac07", null ],
    [ "get_move", "class_x_o___u_i.html#a4814913b14a2666667a2a90ab8205356", null ],
    [ "min_max", "class_x_o___u_i.html#ac33838d3f3f6caed34e73e40a6fa7129", null ]
];