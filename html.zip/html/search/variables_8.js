var searchData=
[
  ['max_5fmoves_0',['max_moves',['../class_four_by_four___moving___board.html#a1c1cd9c65e3e7f9c237cbbdb5e9716e7',1,'FourByFour_Moving_Board']]],
  ['move_5fcount_1',['move_count',['../class_four_by_four___moving___board.html#aeea259731b503f915250f479822efd44',1,'FourByFour_Moving_Board']]],
  ['move_5ftimestamps_2',['move_timestamps',['../class_infinity___board.html#ae296f03e80840e9605498cf078a4d21c',1,'Infinity_Board']]],
  ['moves_5fsince_5flast_5fremoval_3',['moves_since_last_removal',['../class_infinity___board.html#a356e4a4f238650ebf980009f7979adfd',1,'Infinity_Board']]],
  ['movescount_4',['movesCount',['../class_pyramid_tic_tac_toe.html#ac1f9a804cf84f65268b56318ed7375ed',1,'PyramidTicTacToe']]]
];
