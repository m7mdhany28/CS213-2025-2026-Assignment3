var _misere___board_8h =
[
    [ "Misere_Board", "class_misere___board.html", "class_misere___board" ],
    [ "MISERE_BOARD_H", "_misere___board_8h.html#a05623c22c09da21271bc5159a4966b0b", null ]
];