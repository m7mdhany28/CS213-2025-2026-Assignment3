var searchData=
[
  ['playertype_0',['PlayerType',['../_board_game___classes_8h.html#abe590f3c9109f404f003d5d7e4f0fccf',1,'BoardGame_Classes.h']]]
];
