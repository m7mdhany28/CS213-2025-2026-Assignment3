var class_four_in_row___u_i =
[
    [ "FourInRow_UI", "class_four_in_row___u_i.html#aa9f45d6a4dc7340a3148685078046af6", null ],
    [ "create_player", "class_four_in_row___u_i.html#aa09a5ccc815f80282545e1875805d7e1", null ],
    [ "get_AI_move", "class_four_in_row___u_i.html#ad9a4b9c362757435ffbaf90681bd250a", null ],
    [ "get_move", "class_four_in_row___u_i.html#a9ba7b80a0c71ccaa0317c30f4287f616", null ],
    [ "min_max", "class_four_in_row___u_i.html#a810fd0acfa62aa088bb84822bc0588ef", null ],
    [ "setup_players", "class_four_in_row___u_i.html#abe7486ed4e7ca4a3306b25d3c7fcb419", null ]
];