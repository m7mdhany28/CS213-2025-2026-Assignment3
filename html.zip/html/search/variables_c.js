var searchData=
[
  ['rows_0',['ROWS',['../class_pyramid_tic_tac_toe.html#a7016bcfed88b269ef224e1d4c601c676',1,'PyramidTicTacToe']]],
  ['rows_1',['rows',['../class_board.html#a948d978e3b5fc460559b588f5dee9572',1,'Board']]]
];
