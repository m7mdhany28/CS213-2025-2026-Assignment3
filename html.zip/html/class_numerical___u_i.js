var class_numerical___u_i =
[
    [ "Numerical_UI", "class_numerical___u_i.html#a2df77448a71627dbeb30f4c1694e5b2d", null ],
    [ "create_player", "class_numerical___u_i.html#adac3d3b9c67ce9aad8e6dba34db8a8b2", null ],
    [ "get_move", "class_numerical___u_i.html#a0e5f86fdb5fc9b2ed82f12defff1e8bd", null ],
    [ "setup_players", "class_numerical___u_i.html#a04803c425d64f478554d7c2794a277e5", null ]
];