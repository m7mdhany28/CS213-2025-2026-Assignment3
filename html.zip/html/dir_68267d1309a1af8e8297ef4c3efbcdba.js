var dir_68267d1309a1af8e8297ef4c3efbcdba =
[
    [ "Daimond_Classes.cpp", "_daimond___classes_8cpp.html", "_daimond___classes_8cpp" ],
    [ "FourInRow_Board.cpp", "_four_in_row___board_8cpp.html", null ],
    [ "FourInRow_UI.cpp", "_four_in_row___u_i_8cpp.html", null ],
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ],
    [ "MainScreen.cpp", "_main_screen_8cpp.html", null ],
    [ "MemoryGame_Board.cpp", "_memory_game___board_8cpp.html", null ],
    [ "MemoryGame_UI.cpp", "_memory_game___u_i_8cpp.html", null ],
    [ "Numerical_Board.cpp", "_numerical___board_8cpp.html", null ],
    [ "Numerical_UI.cpp", "_numerical___u_i_8cpp.html", null ],
    [ "PlayGameFunctions.cpp", "_play_game_functions_8cpp.html", "_play_game_functions_8cpp" ],
    [ "SUS_Board.cpp", "_s_u_s___board_8cpp.html", null ],
    [ "SUS_UI.cpp", "_s_u_s___u_i_8cpp.html", null ],
    [ "XO_Board.cpp", "_x_o___board_8cpp.html", null ],
    [ "XO_UI.cpp", "_x_o___u_i_8cpp.html", null ]
];