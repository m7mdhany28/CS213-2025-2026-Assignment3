var searchData=
[
  ['o_5fpositions_0',['o_positions',['../class_four_by_four___moving___board.html#addc3baa8a13f2857edb725bf3acef9a5',1,'FourByFour_Moving_Board']]],
  ['order_5fof_5fmoves_1',['order_of_moves',['../class_s_u_s___board.html#a2c99fabf7ad04df1dc7265859f8f0122',1,'SUS_Board']]]
];
