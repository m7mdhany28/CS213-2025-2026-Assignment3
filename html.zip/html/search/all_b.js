var searchData=
[
  ['n_5fmoves_0',['n_moves',['../class_board.html#a5952baefabced65fecec333de638408d',1,'Board']]],
  ['name_1',['name',['../class_player.html#af0ad0d4ca8584d23a98c723cd703a4f6',1,'Player']]],
  ['numerical_5fboard_2',['Numerical_Board',['../class_numerical___board.html',1,'Numerical_Board'],['../class_numerical___board.html#a4fb0e1b6e368c8b6a591fb1d95b19077',1,'Numerical_Board::Numerical_Board()']]],
  ['numerical_5fboard_2ecpp_3',['Numerical_Board.cpp',['../_numerical___board_8cpp.html',1,'']]],
  ['numerical_5fboard_2eh_4',['Numerical_Board.h',['../_numerical___board_8h.html',1,'']]],
  ['numerical_5fui_5',['Numerical_UI',['../class_numerical___u_i.html',1,'Numerical_UI'],['../class_numerical___u_i.html#a2df77448a71627dbeb30f4c1694e5b2d',1,'Numerical_UI::Numerical_UI()']]],
  ['numerical_5fui_2ecpp_6',['Numerical_UI.cpp',['../_numerical___u_i_8cpp.html',1,'']]],
  ['numerical_5fui_2eh_7',['Numerical_UI.h',['../_numerical___u_i_8h.html',1,'']]],
  ['numericalgame_8',['NUMERICALGAME',['../class_main_screen.html#a5e0cc247f5b321d4dfb8367e75e53e00a804a3370c931aaf1c0e6410ad5f63016',1,'MainScreen']]]
];
