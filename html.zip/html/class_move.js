var class_move =
[
    [ "Move", "class_move.html#a100102cb072a2857304023233dac7b42", null ],
    [ "get_symbol", "class_move.html#a595bf740852c05a1cb425ef2640fd4ff", null ],
    [ "get_x", "class_move.html#a9d4f543a81e361f872d37bcfb64d5b55", null ],
    [ "get_y", "class_move.html#a96469802a55c9083a1e93c7edec8a00c", null ],
    [ "symbol", "class_move.html#a0bec25acdce91feab1b4c21c26505088", null ],
    [ "x", "class_move.html#a5f399fb722305d3061e0f6f2438e5390", null ],
    [ "y", "class_move.html#abe58a4df9d3e121d06a3b2d1815f012e", null ]
];