var class_main_screen =
[
    [ "UserChoice", "class_main_screen.html#a5e0cc247f5b321d4dfb8367e75e53e00", [
      [ "XOGAME", "class_main_screen.html#a5e0cc247f5b321d4dfb8367e75e53e00a8e344c4e65c9fb438ffdb833e7eb48ee", null ],
      [ "NUMERICALGAME", "class_main_screen.html#a5e0cc247f5b321d4dfb8367e75e53e00a804a3370c931aaf1c0e6410ad5f63016", null ],
      [ "SUSGAME", "class_main_screen.html#a5e0cc247f5b321d4dfb8367e75e53e00afdcac34a5ffb1df9679fdaabde11a9d8", null ],
      [ "FOURINROWGAME", "class_main_screen.html#a5e0cc247f5b321d4dfb8367e75e53e00a787519dad44da6bfb67d9d39d0b34ec6", null ],
      [ "INFINITYGAME", "class_main_screen.html#a5e0cc247f5b321d4dfb8367e75e53e00aa28f4ce73f0a421a510a29c0aff09852", null ],
      [ "MISERE", "class_main_screen.html#a5e0cc247f5b321d4dfb8367e75e53e00a52868d9b86bd40646bb6f37a122da942", null ],
      [ "FIVE_BY_FIVE", "class_main_screen.html#a5e0cc247f5b321d4dfb8367e75e53e00a7d0f8709c51524ab14b02c2321e57365", null ],
      [ "WORD", "class_main_screen.html#a5e0cc247f5b321d4dfb8367e75e53e00abdde29e3c0fe7b687d69a696bbaf71ac", null ],
      [ "MOVING", "class_main_screen.html#a5e0cc247f5b321d4dfb8367e75e53e00aaf5a690fd5ec6f789dbfc51ec6a891ba", null ],
      [ "PYRAMID", "class_main_screen.html#a5e0cc247f5b321d4dfb8367e75e53e00acd996d3184761601a0e44e587a012d4f", null ],
      [ "MEMORYGAME", "class_main_screen.html#a5e0cc247f5b321d4dfb8367e75e53e00a687135f07f6af561f12a2d1554958269", null ],
      [ "DIAMONDGAME", "class_main_screen.html#a5e0cc247f5b321d4dfb8367e75e53e00ae707c4ae4c1380a3807066ccde739d6b", null ],
      [ "EXIT", "class_main_screen.html#a5e0cc247f5b321d4dfb8367e75e53e00aa42b2fb0e720a080e79a92f4ca97d927", null ]
    ] ],
    [ "implementUserChoice", "class_main_screen.html#a26fa50a5869b41fe58f68892e50ceec1", null ],
    [ "printMainMenuScreen", "class_main_screen.html#a74c3ed84d2d3e68720d45ab76b9e8195", null ],
    [ "startBoardGameProgram", "class_main_screen.html#aac272e272aea4e977baad607c0d0aefc", null ]
];