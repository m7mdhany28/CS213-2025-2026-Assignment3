var indexSectionsWithContent =
{
  0: "abcdefghilmnoprstuvwxy~",
  1: "bdfgimnpsuwx",
  2: "bdfimnpswx",
  3: "bcdefghilmnprsuvwx~",
  4: "abcdfgilmnoprstuwxy",
  5: "pu",
  6: "acdefhimnprswx",
  7: "fimpsw"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "enumvalues",
  7: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Enumerations",
  6: "Enumerator",
  7: "Macros"
};

