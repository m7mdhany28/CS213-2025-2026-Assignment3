var hierarchy =
[
    [ "Board&lt; T &gt;", "class_board.html", null ],
    [ "Board&lt; char &gt;", "class_board.html", [
      [ "Diamond_Board", "class_diamond___board.html", null ],
      [ "FiveByFive_Board", "class_five_by_five___board.html", null ],
      [ "FourByFour_Moving_Board", "class_four_by_four___moving___board.html", null ],
      [ "FourInRow_Board", "class_four_in_row___board.html", null ],
      [ "Infinity_Board", "class_infinity___board.html", null ],
      [ "MemoryGame_Board", "class_memory_game___board.html", null ],
      [ "Misere_Board", "class_misere___board.html", null ],
      [ "SUS_Board", "class_s_u_s___board.html", null ],
      [ "WordTicTacToe_Board", "class_word_tic_tac_toe___board.html", null ],
      [ "X_O_Board", "class_x___o___board.html", null ]
    ] ],
    [ "Board&lt; int &gt;", "class_board.html", [
      [ "Numerical_Board", "class_numerical___board.html", null ]
    ] ],
    [ "GameManager&lt; T &gt;", "class_game_manager.html", null ],
    [ "MainScreen", "class_main_screen.html", null ],
    [ "Move&lt; T &gt;", "class_move.html", null ],
    [ "Player&lt; T &gt;", "class_player.html", null ],
    [ "PlayGameFunctions", "class_play_game_functions.html", null ],
    [ "PyramidTicTacToe", "class_pyramid_tic_tac_toe.html", null ],
    [ "UI&lt; T &gt;", "class_u_i.html", null ],
    [ "UI&lt; char &gt;", "class_u_i.html", [
      [ "Diamond_UI", "class_diamond___u_i.html", null ],
      [ "FourInRow_UI", "class_four_in_row___u_i.html", null ],
      [ "MemoryGame_UI", "class_memory_game___u_i.html", null ],
      [ "SUS_UI", "class_s_u_s___u_i.html", null ],
      [ "Simple_UI", "class_simple___u_i.html", null ],
      [ "XO_UI", "class_x_o___u_i.html", null ]
    ] ],
    [ "UI&lt; int &gt;", "class_u_i.html", [
      [ "Numerical_UI", "class_numerical___u_i.html", null ]
    ] ]
];