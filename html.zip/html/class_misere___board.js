var class_misere___board =
[
    [ "Misere_Board", "class_misere___board.html#af98de28668fd6c3a9b6d6b1da82c643e", null ],
    [ "display_board", "class_misere___board.html#a4af7cc5a50d55eb8a6955c24b8169ccb", null ],
    [ "game_is_over", "class_misere___board.html#afcca94e613d7d43fac5f6fe841d1d760", null ],
    [ "get_board_state", "class_misere___board.html#a3d8368ca79986a9313d597577385c2b0", null ],
    [ "has_three_in_row", "class_misere___board.html#a0b2a63ab492118c7881b0479d937f654", null ],
    [ "is_draw", "class_misere___board.html#aab74b353342b36b268bd2c46f5c788f9", null ],
    [ "is_lose", "class_misere___board.html#a186fb7b780c5d17db6919b352dcb3194", null ],
    [ "is_win", "class_misere___board.html#aea6c6a5249f718caa00e52219dd90b14", null ],
    [ "update_board", "class_misere___board.html#a32c93d676416311b19754f60b1468450", null ]
];