var searchData=
[
  ['remove_5foldest_5fmark_0',['remove_oldest_mark',['../class_infinity___board.html#a6f51a8fa6b6bb98f639a87a2aa063b05',1,'Infinity_Board']]],
  ['reset_1',['reset',['../class_pyramid_tic_tac_toe.html#ad280e6e2ef82aa522576a1905fccc695',1,'PyramidTicTacToe']]],
  ['run_2',['run',['../class_game_manager.html#a71f46d5189dac5c773f608cea1b5a203',1,'GameManager']]]
];
