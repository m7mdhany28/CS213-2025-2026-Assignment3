var searchData=
[
  ['xogame_0',['XOGAME',['../class_main_screen.html#a5e0cc247f5b321d4dfb8367e75e53e00a8e344c4e65c9fb438ffdb833e7eb48ee',1,'MainScreen']]]
];
