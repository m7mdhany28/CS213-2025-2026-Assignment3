var class_game_manager =
[
    [ "GameManager", "class_game_manager.html#addaf3682d9783bdc432a8e3273b5b92c", null ],
    [ "run", "class_game_manager.html#a71f46d5189dac5c773f608cea1b5a203", null ],
    [ "boardPtr", "class_game_manager.html#a97608354a255ec6916f64fc51e49f9e1", null ],
    [ "players", "class_game_manager.html#abc7b7dc6bd0e89a29886ace8a7db60bd", null ],
    [ "ui", "class_game_manager.html#a2a3d79a969e0ff1ae529058779039ea9", null ]
];