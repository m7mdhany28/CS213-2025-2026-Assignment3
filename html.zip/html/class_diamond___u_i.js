var class_diamond___u_i =
[
    [ "Diamond_UI", "class_diamond___u_i.html#ab324b9b8948308b1480ded25a7081e7a", null ],
    [ "~Diamond_UI", "class_diamond___u_i.html#a7e9cb78d09208e869db036673a7c17b5", null ],
    [ "create_player", "class_diamond___u_i.html#a9c4e43d9cf1a603c3e487bbfabd13a83", null ],
    [ "display_board_matrix", "class_diamond___u_i.html#af494b3823e26b4bbaa63239f6e500fbc", null ],
    [ "get_move", "class_diamond___u_i.html#ac2d48ab1b25be3ef0513f86adab7584e", null ]
];