var class_play_game_functions =
[
    [ "play5x5Game", "class_play_game_functions.html#a8de67ed8df032cab700584e6d01c1fbd", null ],
    [ "playDiamondGame", "class_play_game_functions.html#abbfbc8b471de6ba7390d8fc72a690aaf", null ],
    [ "playFourInRowGame", "class_play_game_functions.html#afcb3f50cb80b811a671435d9346c858e", null ],
    [ "playInfinityGame", "class_play_game_functions.html#a9e8fbf884e84eedf4563dc3d8d0b66de", null ],
    [ "playMemoryGame", "class_play_game_functions.html#a796a7cb829c39d3af815f9d58977a85b", null ],
    [ "playMisereGame", "class_play_game_functions.html#a4db34b57f7e0d67f8faed5b46030bb2a", null ],
    [ "playMovingGame", "class_play_game_functions.html#a9c5b2c732da9b64e0fe37f58c307e57a", null ],
    [ "playNumericalGame", "class_play_game_functions.html#a7c0ab1cfd16ec2dcadd8cca9ac4da255", null ],
    [ "playPyramidGame", "class_play_game_functions.html#a57e87b381afdfb1ad3be54fd3849cf66", null ],
    [ "playSUSGame", "class_play_game_functions.html#adf294a9eb518afda0a32f6dbdc0043f6", null ],
    [ "playWordGame", "class_play_game_functions.html#ac7358a30d47c5c64fcb90b600a3683b8", null ],
    [ "playXOGame", "class_play_game_functions.html#a1ed845cfd51d3098bf6657d4eb782af9", null ]
];