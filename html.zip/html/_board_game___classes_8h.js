var _board_game___classes_8h =
[
    [ "Board&lt; T &gt;", "class_board.html", "class_board" ],
    [ "Move&lt; T &gt;", "class_move.html", "class_move" ],
    [ "Player&lt; T &gt;", "class_player.html", "class_player" ],
    [ "UI&lt; T &gt;", "class_u_i.html", "class_u_i" ],
    [ "GameManager&lt; T &gt;", "class_game_manager.html", "class_game_manager" ],
    [ "PlayerType", "_board_game___classes_8h.html#abe590f3c9109f404f003d5d7e4f0fccf", [
      [ "HUMAN", "_board_game___classes_8h.html#abe590f3c9109f404f003d5d7e4f0fccfaa36c6719f4d3207d858cf956ef1e93b6", null ],
      [ "COMPUTER", "_board_game___classes_8h.html#abe590f3c9109f404f003d5d7e4f0fccfad19cbc472227d1e3d1d276c2cbc0e513", null ],
      [ "AI", "_board_game___classes_8h.html#abe590f3c9109f404f003d5d7e4f0fccfa0a40e3c91a3a55c9a37428c6d194d0e5", null ],
      [ "RANDOM", "_board_game___classes_8h.html#abe590f3c9109f404f003d5d7e4f0fccfa170e02e86972c2be8559884cc3c12254", null ]
    ] ]
];