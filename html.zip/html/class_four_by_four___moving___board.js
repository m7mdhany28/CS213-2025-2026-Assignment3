var class_four_by_four___moving___board =
[
    [ "FourByFour_Moving_Board", "class_four_by_four___moving___board.html#a55b8aa6b36e76d867d331bfeec2d1871", null ],
    [ "check_win", "class_four_by_four___moving___board.html#a45ee25efed833522c8bf323ecc98800a", null ],
    [ "display_board", "class_four_by_four___moving___board.html#a9aa2cdb34a48744fc6176f10ecf36d8e", null ],
    [ "game_is_over", "class_four_by_four___moving___board.html#aab69320a981841fa425117b6f2a513c4", null ],
    [ "generate_valid_moves_for_player", "class_four_by_four___moving___board.html#a57dd217b55fd5149880eb8595ee80ae0", null ],
    [ "get_player_positions", "class_four_by_four___moving___board.html#a9504fc52e8cdf188cc769ad49d211948", null ],
    [ "has_valid_moves", "class_four_by_four___moving___board.html#a8f513fb1f8babbf967a120590d1a8cef", null ],
    [ "is_draw", "class_four_by_four___moving___board.html#a8777796ebd9cf9adb6f5e58548a7ab23", null ],
    [ "is_lose", "class_four_by_four___moving___board.html#a73c3fc54455d0cee1d247b21879d5a1a", null ],
    [ "is_win", "class_four_by_four___moving___board.html#a4416e36413fc2d424a6e925cc791ca5a", null ],
    [ "setup_starting_positions", "class_four_by_four___moving___board.html#ae678f6fd10032d914d5da43c5f77633f", null ],
    [ "update_board", "class_four_by_four___moving___board.html#a1e3ffb6c7321046a0fdddb5d7293fba5", null ],
    [ "would_create_three_in_row", "class_four_by_four___moving___board.html#a68b8538edb6f4423a67b098de9a6e418", null ],
    [ "game_ended", "class_four_by_four___moving___board.html#aeffdd500d96b241536ddd350d118eea3", null ],
    [ "max_moves", "class_four_by_four___moving___board.html#a1c1cd9c65e3e7f9c237cbbdb5e9716e7", null ],
    [ "move_count", "class_four_by_four___moving___board.html#aeea259731b503f915250f479822efd44", null ],
    [ "o_positions", "class_four_by_four___moving___board.html#addc3baa8a13f2857edb725bf3acef9a5", null ],
    [ "x_positions", "class_four_by_four___moving___board.html#a9996d1b01bd2e663c3175251f95691df", null ]
];