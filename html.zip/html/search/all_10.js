var searchData=
[
  ['total_5fmoves_0',['total_moves',['../class_infinity___board.html#a5ca3b3f82d14d26b114b9f1217a942f7',1,'Infinity_Board']]],
  ['type_1',['type',['../class_player.html#a81a15b1b507fd5f2157fb15bf0fd283f',1,'Player']]]
];
