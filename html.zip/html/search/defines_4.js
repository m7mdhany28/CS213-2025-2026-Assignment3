var searchData=
[
  ['simple_5fui_5fh_0',['SIMPLE_UI_H',['../_simple___u_i_8h.html#a5a18bd92e8e9d83c011f82c5e28e51c6',1,'Simple_UI.h']]]
];
