var searchData=
[
  ['game_5fboard_0',['game_board',['../class_simple___u_i.html#a65ba76bb72b0247caf60d2f2197a404e',1,'Simple_UI']]],
  ['game_5fended_1',['game_ended',['../class_four_by_four___moving___board.html#aeffdd500d96b241536ddd350d118eea3',1,'FourByFour_Moving_Board']]],
  ['game_5ftype_2',['game_type',['../class_simple___u_i.html#ad283e312eeb2a1922dfeb99fb633182d',1,'Simple_UI']]],
  ['gameover_3',['gameOver',['../class_pyramid_tic_tac_toe.html#ad28d889e2a7542ae9180e0b86c1dcc2b',1,'PyramidTicTacToe']]]
];
