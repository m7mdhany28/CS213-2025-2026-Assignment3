var class_memory_game___u_i =
[
    [ "MemoryGame_UI", "class_memory_game___u_i.html#a2af1414cb867878a7e6c13d26afc7350", null ],
    [ "~MemoryGame_UI", "class_memory_game___u_i.html#aec5c2606b6316875bb484afac322c13a", null ],
    [ "create_player", "class_memory_game___u_i.html#add442ba5ee4d6bb856fc1e475c1004fc", null ],
    [ "get_move", "class_memory_game___u_i.html#ac09ae74bc25f98f476b8ff78fe7791a3", null ]
];