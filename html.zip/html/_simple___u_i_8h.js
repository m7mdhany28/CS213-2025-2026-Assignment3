var _simple___u_i_8h =
[
    [ "Simple_UI", "class_simple___u_i.html", "class_simple___u_i" ],
    [ "SIMPLE_UI_H", "_simple___u_i_8h.html#a5a18bd92e8e9d83c011f82c5e28e51c6", null ]
];