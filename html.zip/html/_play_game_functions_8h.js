var _play_game_functions_8h =
[
    [ "PlayGameFunctions", "class_play_game_functions.html", "class_play_game_functions" ],
    [ "PLAY_GAME_FUNCTIONS_H", "_play_game_functions_8h.html#ac9884b3a3a8aef86913d2bbb1eab13f7", null ],
    [ "choosePlayerPersonality", "_play_game_functions_8h.html#af79f90289f726743b7076a84a4122142", null ],
    [ "getPlayerIdentity", "_play_game_functions_8h.html#a0e7eec747f8c9264b1eb6b8d28de8871", null ]
];