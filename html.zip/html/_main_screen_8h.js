var _main_screen_8h =
[
    [ "MainScreen", "class_main_screen.html", "class_main_screen" ],
    [ "MAIN_SCREEN_H", "_main_screen_8h.html#a38f72c91229b0da1392339f4a8c921b1", null ]
];