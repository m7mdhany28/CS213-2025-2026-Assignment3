var searchData=
[
  ['numerical_5fboard_0',['Numerical_Board',['../class_numerical___board.html#a4fb0e1b6e368c8b6a591fb1d95b19077',1,'Numerical_Board']]],
  ['numerical_5fui_1',['Numerical_UI',['../class_numerical___u_i.html#a2df77448a71627dbeb30f4c1694e5b2d',1,'Numerical_UI']]]
];
