var searchData=
[
  ['x_0',['x',['../class_move.html#a5f399fb722305d3061e0f6f2438e5390',1,'Move']]],
  ['x_5fpositions_1',['x_positions',['../class_four_by_four___moving___board.html#a9996d1b01bd2e663c3175251f95691df',1,'FourByFour_Moving_Board']]]
];
