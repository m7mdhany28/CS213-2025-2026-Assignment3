var searchData=
[
  ['_7eboard_0',['~Board',['../class_board.html#a138a6378af669dd1ce55dc11217aea48',1,'Board']]],
  ['_7ediamond_5fui_1',['~Diamond_UI',['../class_diamond___u_i.html#a7e9cb78d09208e869db036673a7c17b5',1,'Diamond_UI']]],
  ['_7ememorygame_5fui_2',['~MemoryGame_UI',['../class_memory_game___u_i.html#aec5c2606b6316875bb484afac322c13a',1,'MemoryGame_UI']]],
  ['_7enumerical_5fboard_3',['~Numerical_Board',['../class_numerical___board.html#a9f012574beec61ed793d1322d5722b24',1,'Numerical_Board']]],
  ['_7eplayer_4',['~Player',['../class_player.html#aac1f2ab2a8e2aa0336d302c16068020e',1,'Player']]],
  ['_7eui_5',['~UI',['../class_u_i.html#a1012e508ff7df030714c62ddf6b261a7',1,'UI']]],
  ['_7exo_5fui_6',['~XO_UI',['../class_x_o___u_i.html#a6c58a77a2fa80f73e7076ca4a94fcc8a',1,'XO_UI']]]
];
