var searchData=
[
  ['set_5fboard_5fptr_0',['set_board_ptr',['../class_player.html#a3617a3ad0db435176a06948065f9a3a6',1,'Player']]],
  ['set_5fpyramid_5fgame_1',['set_pyramid_game',['../class_simple___u_i.html#a4b72c4a4f32b1b2f2f5d39301edd6bd4',1,'Simple_UI']]],
  ['setup_5fplayers_2',['setup_players',['../class_u_i.html#a6966a040c995b2292e5edddaa94f889a',1,'UI::setup_players()'],['../class_four_in_row___u_i.html#abe7486ed4e7ca4a3306b25d3c7fcb419',1,'FourInRow_UI::setup_players()'],['../class_numerical___u_i.html#a04803c425d64f478554d7c2794a277e5',1,'Numerical_UI::setup_players()'],['../class_s_u_s___u_i.html#a24c1d67ea76050e7bee6159e9ba39aa2',1,'SUS_UI::setup_players()']]],
  ['setup_5fstarting_5fpositions_3',['setup_starting_positions',['../class_four_by_four___moving___board.html#ae678f6fd10032d914d5da43c5f77633f',1,'FourByFour_Moving_Board']]],
  ['simple_5fui_4',['Simple_UI',['../class_simple___u_i.html#a116e9423a02d49ceb2915fa18e67d12d',1,'Simple_UI']]],
  ['startboardgameprogram_5',['startBoardGameProgram',['../class_main_screen.html#aac272e272aea4e977baad607c0d0aefc',1,'MainScreen']]],
  ['sus_5fboard_6',['SUS_Board',['../class_s_u_s___board.html#a653be0dfe8070a59361bd228c0b54f71',1,'SUS_Board']]],
  ['sus_5fui_7',['SUS_UI',['../class_s_u_s___u_i.html#ac1a13d00ecf04b1ea3af53f1c08949c1',1,'SUS_UI']]]
];
