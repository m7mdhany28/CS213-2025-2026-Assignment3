var class_numerical___board =
[
    [ "Numerical_Board", "class_numerical___board.html#a4fb0e1b6e368c8b6a591fb1d95b19077", null ],
    [ "~Numerical_Board", "class_numerical___board.html#a9f012574beec61ed793d1322d5722b24", null ],
    [ "game_is_over", "class_numerical___board.html#af99571b4b13a158516702a9f1ab2bba9", null ],
    [ "is_draw", "class_numerical___board.html#aeed87eaf1055fefff316d33e32959eab", null ],
    [ "is_lose", "class_numerical___board.html#a2019490db1e1a0c09020e7a7ba4269b4", null ],
    [ "is_win", "class_numerical___board.html#aae10be94151c42e6f3cb9ab8fe45616e", null ],
    [ "update_board", "class_numerical___board.html#a28020ed5677f1a6b77589f0322b02669", null ],
    [ "Blank_Symbol", "class_numerical___board.html#aa4319148562223d0ca59bc7412c26bd0", null ]
];