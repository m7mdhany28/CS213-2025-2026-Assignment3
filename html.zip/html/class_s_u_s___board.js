var class_s_u_s___board =
[
    [ "SUS_Board", "class_s_u_s___board.html#a653be0dfe8070a59361bd228c0b54f71", null ],
    [ "calculate_players_score", "class_s_u_s___board.html#ad9b301a7f2bcb678bbec370905983809", null ],
    [ "game_is_over", "class_s_u_s___board.html#acd2c39612239065da3aea67ac7c27aa4", null ],
    [ "is_draw", "class_s_u_s___board.html#aeb2ad5ce9bdd10ecf2d3cf06be14e6ca", null ],
    [ "is_lose", "class_s_u_s___board.html#a3761b3ce05e2194ff95893b494a3c933", null ],
    [ "is_win", "class_s_u_s___board.html#a2230a0e70a119a14e7e7380ba9b2cb90", null ],
    [ "update_board", "class_s_u_s___board.html#a22679cdc9a91a17fea898c66ad821e45", null ],
    [ "valid_move", "class_s_u_s___board.html#a7fc185f07055fd7e3252f24d46612919", null ],
    [ "Blank_Symbol", "class_s_u_s___board.html#a8f954e1b818601341fd0cb9125a46c66", null ],
    [ "order_of_moves", "class_s_u_s___board.html#a2c99fabf7ad04df1dc7265859f8f0122", null ]
];