var searchData=
[
  ['infinitygame_0',['INFINITYGAME',['../class_main_screen.html#a5e0cc247f5b321d4dfb8367e75e53e00aa28f4ce73f0a421a510a29c0aff09852',1,'MainScreen']]]
];
