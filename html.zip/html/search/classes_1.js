var searchData=
[
  ['diamond_5fboard_0',['Diamond_Board',['../class_diamond___board.html',1,'']]],
  ['diamond_5fui_1',['Diamond_UI',['../class_diamond___u_i.html',1,'']]]
];
