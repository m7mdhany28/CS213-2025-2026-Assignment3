var class_player =
[
    [ "Player", "class_player.html#adb4e803a7ac0356b111b8ca79d766976", null ],
    [ "~Player", "class_player.html#aac1f2ab2a8e2aa0336d302c16068020e", null ],
    [ "get_board_ptr", "class_player.html#a508617eddfae8915d098102d480fc888", null ],
    [ "get_name", "class_player.html#aed2af19790ba73190e3ebeea589518e1", null ],
    [ "get_symbol", "class_player.html#af56f0bf98c0423a3a75b0848607d03a4", null ],
    [ "get_type", "class_player.html#a2df3bd299bf7aecfa2275ec6902a60f8", null ],
    [ "set_board_ptr", "class_player.html#a3617a3ad0db435176a06948065f9a3a6", null ],
    [ "boardPtr", "class_player.html#a26249e756f850b6585267bfbc928ac79", null ],
    [ "name", "class_player.html#af0ad0d4ca8584d23a98c723cd703a4f6", null ],
    [ "symbol", "class_player.html#a272d6c4dab769930d4f8074918e7708a", null ],
    [ "type", "class_player.html#a81a15b1b507fd5f2157fb15bf0fd283f", null ]
];