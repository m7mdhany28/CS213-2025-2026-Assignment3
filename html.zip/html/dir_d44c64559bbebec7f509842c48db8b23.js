var dir_d44c64559bbebec7f509842c48db8b23 =
[
    [ "BoardGame_Classes.h", "_board_game___classes_8h.html", "_board_game___classes_8h" ],
    [ "Diamond_Classes.h", "_diamond___classes_8h.html", "_diamond___classes_8h" ],
    [ "FiveByFive_Board.h", "_five_by_five___board_8h.html", "_five_by_five___board_8h" ],
    [ "FourByFour_Moving_Board.h", "_four_by_four___moving___board_8h.html", "_four_by_four___moving___board_8h" ],
    [ "FourInRow_Board.h", "_four_in_row___board_8h.html", "_four_in_row___board_8h" ],
    [ "FourInRow_UI.h", "_four_in_row___u_i_8h.html", "_four_in_row___u_i_8h" ],
    [ "Infinity_Board.h", "_infinity___board_8h.html", "_infinity___board_8h" ],
    [ "MainScreen.h", "_main_screen_8h.html", "_main_screen_8h" ],
    [ "MemoryGame_Board.h", "_memory_game___board_8h.html", "_memory_game___board_8h" ],
    [ "MemoryGame_UI.h", "_memory_game___u_i_8h.html", "_memory_game___u_i_8h" ],
    [ "Misere_Board.h", "_misere___board_8h.html", "_misere___board_8h" ],
    [ "Numerical_Board.h", "_numerical___board_8h.html", "_numerical___board_8h" ],
    [ "Numerical_UI.h", "_numerical___u_i_8h.html", "_numerical___u_i_8h" ],
    [ "PlayGameFunctions.h", "_play_game_functions_8h.html", "_play_game_functions_8h" ],
    [ "pyramid_tic_tac_toe.h", "pyramid__tic__tac__toe_8h.html", "pyramid__tic__tac__toe_8h" ],
    [ "Simple_UI.h", "_simple___u_i_8h.html", "_simple___u_i_8h" ],
    [ "SUS_Board.h", "_s_u_s___board_8h.html", "_s_u_s___board_8h" ],
    [ "SUS_UI.h", "_s_u_s___u_i_8h.html", "_s_u_s___u_i_8h" ],
    [ "WordTicTacToe_Board.h", "_word_tic_tac_toe___board_8h.html", "_word_tic_tac_toe___board_8h" ],
    [ "XO_Board.h", "_x_o___board_8h.html", "_x_o___board_8h" ],
    [ "XO_UI.h", "_x_o___u_i_8h.html", "_x_o___u_i_8h" ]
];